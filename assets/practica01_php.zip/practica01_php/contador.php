<?php


/* Configuración y cálculo del contador */

date_default_timezone_set('Europe/Madrid');

$ahora = new DateTime('now');

$objetivo = new DateTime('2026-01-01 00:00:00');

if ($ahora >= $objetivo) {
    $finalizado = true;
    $dias = $horas = $minutos = $segundos = 0;
} else {
    $finalizado = false;
    $intervalo = $ahora->diff($objetivo);

    $dias     = $intervalo->days;
    $horas    = $intervalo->h;
    $minutos  = $intervalo->i;
    $segundos = $intervalo->s;
}

?>


<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Contador Año Nuevo 2026</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <?php if (!$finalizado): ?>
        <meta http-equiv="refresh" content="1">
    <?php endif; ?>

    <meta name="theme-color" content="#000000">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>


    <!-- Tipografías navideñas -->
    
    <link
        href="https://fonts.googleapis.com/css2?family=Mountains+of+Christmas:wght@400;700&family=Great+Vibes&family=Nunito:wght@300;600;800&display=swap"
        rel="stylesheet"
    >


    <!-- CSS -->
    <link rel="preload" href="css/style.css" as="style">
    <link rel="stylesheet" href="css/style.css">

</head>

<body class="page-countdown">


    <!-- Contenedor principal -->
    
    <div class="page-wrapper">


        <!-- Header -->
        
        <header class="main-header">
            <h1 class="site-title">Cuenta atrás para el 2026</h1>
            <p class="site-subtitle">Brillos, deseos y un nuevo comienzo</p>
        </header>


        <!-- Main -->
        
        <main class="main-content">
            <section class="countdown-section">

                <?php if ($finalizado): ?>
                    <div class="happy-new-year">
                        <h2>¡FELIZ AÑO NUEVO 2026!</h2>
                        <p>
                            Que este año traiga mucha alegria y salud y se cumplan tus deseos.
                        </p>
                    </div>

                <?php else: ?>
                    <h2 class="countdown-title">Faltan...</h2>
                    <div class="countdown-container">

                        <div class="time-box">
                            <span class="time-number"><?php echo $dias; ?></span>
                            <span class="time-label">Días</span>
                        </div>

                        <div class="time-box">
                            <span class="time-number">
                                <?php echo str_pad($horas, 2, '0', STR_PAD_LEFT); ?>
                            </span>
                            <span class="time-label">Horas</span>
                        </div>

                        <div class="time-box">
                            <span class="time-number">
                                <?php echo str_pad($minutos, 2, '0', STR_PAD_LEFT); ?>
                            </span>
                            <span class="time-label">Minutos</span>
                        </div>

                        <div class="time-box">
                            <span class="time-number">
                                <?php echo str_pad($segundos, 2, '0', STR_PAD_LEFT); ?>
                            </span>
                            <span class="time-label">Segundos</span>
                        </div>
                    </div>

                    <p class="countdown-note">
                        Observa como cada vez queda menos para llegar a 2026.
                    </p>
                <?php endif; ?>

                <div class="buttons-row">
                    <a href="index.php" class="btn btn-secondary">Volver a la carta</a>
                </div>
            </section>
        </main>


        <!-- Footer -->
        
        <footer class="main-footer">
            <p>¡Despide el año con una sonrisa!</p>
        </footer>
    </div>
</body>
</html>

