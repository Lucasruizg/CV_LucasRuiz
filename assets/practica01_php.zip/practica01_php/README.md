# Carta a los Reyes Magos 🎄

Aplicación web PHP para enviar cartas a los Reyes Magos con un contador regresivo hasta el Año Nuevo 2026.

## 📋 Descripción

Esta aplicación permite a los usuarios enviar sus cartas navideñas a los Reyes Magos a través de un formulario interactivo. Las cartas se almacenan en una base de datos MySQL y la aplicación incluye un contador regresivo hasta el Año Nuevo 2026.

## ✨ Características

- **Formulario de carta navideña**: Permite enviar cartas con nombre, edad, dirección, mensaje y confirmación de buen comportamiento
- **Contador regresivo**: Muestra el tiempo restante hasta el Año Nuevo 2026 con actualización en tiempo real
- **Diseño navideño**: Interfaz temática con animaciones de nieve, efectos visuales y tipografías navideñas
- **Validación de datos**: Validación del lado del servidor para todos los campos del formulario
- **Base de datos MySQL**: Almacenamiento seguro de las cartas usando PDO

## 🛠️ Tecnologías Utilizadas

- **PHP 7.4+** (con strict types)
- **MySQL** (PDO)
- **HTML5**
- **CSS3** (con animaciones y efectos visuales)
- **Google Fonts** (Mountains of Christmas, Great Vibes, Nunito)

## 📁 Estructura del Proyecto

```
practica01_php/
├── assets/                    # Imágenes y recursos
│   ├── reyes_magos.png
│   ├── estrella-belen-podra-verse-cielo-800-despues-876548.jpg
│   └── 4daddd4f-1ac4-4865-8fa9-178ba15083b3-removebg-preview.png
├── bbdd/
│   └── server.php            # Configuración de conexión a la base de datos
├── css/
│   └── style.css             # Estilos principales
├── contador.php              # Página del contador regresivo
├── index.php                 # Página principal con el formulario
└── README.md                 # Este archivo
```

## 🚀 Instalación

### Requisitos Previos

- Servidor web (Apache, Nginx, o PHP built-in server)
- PHP 7.4 o superior
- MySQL 5.7 o superior
- Extensión PDO de PHP habilitada

### Pasos de Instalación

1. **Clonar o descargar el proyecto**
   ```bash
   git clone <url-del-repositorio>
   cd practica01_php
   ```

2. **Crear la base de datos**
   ```sql
   CREATE DATABASE reyes_magos;
   USE reyes_magos;
   
   CREATE TABLE cartas_reyes (
       id INT AUTO_INCREMENT PRIMARY KEY,
       nombre VARCHAR(100) NOT NULL,
       edad INT NOT NULL,
       direccion VARCHAR(255) NOT NULL,
       carta TEXT NOT NULL,
       buen_comportamiento TINYINT(1) DEFAULT 0,
       fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
   );
   ```

3. **Configurar la conexión a la base de datos**
   
   Edita el archivo `bbdd/server.php` y actualiza las credenciales:
   ```php
   $host = '127.0.0.1';
   $port = '3306';
   $db   = 'reyes_magos';
   $user = 'tu_usuario';
   $pass = 'tu_contraseña';
   ```

4. **Iniciar el servidor**
   
   **Opción 1: Servidor PHP integrado**
   ```bash
   php -S localhost:8000
   ```
   
   **Opción 2: Apache/Nginx**
   - Configura tu servidor web para apuntar al directorio del proyecto
   - Asegúrate de que las rutas CSS y assets sean accesibles

5. **Acceder a la aplicación**
   
   Abre tu navegador y visita:
   ```
   http://localhost:8000
   ```

## 📝 Uso

### Enviar una Carta

1. Accede a la página principal (`index.php`)
2. Completa el formulario con:
   - Nombre completo
   - Edad (0-120)
   - Dirección completa
   - Tu carta/deseos
   - Marca si te has portado bien este año
3. Haz clic en "Enviar carta a Oriente"
4. Verás un mensaje de confirmación si la carta se guardó correctamente

### Ver el Contador

1. En la página principal, haz clic en las uvas verdes
2. Serás redirigido a `contador.php` que muestra el tiempo restante hasta el 2026
3. El contador se actualiza automáticamente cada segundo

**¿Qué pasa cuando llega el año nuevo?**
- Una vez alcanzada la fecha objetivo (1 de enero de 2026 a las 00:00:00), el contador se detiene automáticamente
- Se muestra un mensaje de felicitación: "¡FELIZ AÑO NUEVO 2026!"
- El contador deja de actualizarse y permanece estático mostrando el mensaje de celebración

## 🔒 Validaciones

El formulario valida:
- **Nombre**: No vacío, máximo 100 caracteres
- **Edad**: Entre 0 y 120 años
- **Dirección**: No vacía, máximo 255 caracteres
- **Carta**: No vacía, máximo 5000 caracteres

## 🎨 Características de Diseño

- Animaciones de nieve en múltiples capas
- Efectos de hover en botones y elementos interactivos
- Diseño responsive para dispositivos móviles
- Tipografías navideñas personalizadas
- Fondos con efectos visuales y gradientes
- Animación de flotación en la imagen de los Reyes Magos

## ⚙️ Configuración

### Zona Horaria

La aplicación está configurada para usar la zona horaria `Europe/Madrid`. Puedes cambiarla en:
- `index.php` (línea 3)
- `contador.php` (línea 6)

### Fecha Objetivo del Contador

El contador está configurado para el **1 de enero de 2026**. Para cambiarlo, edita `contador.php`:
```php
$objetivo = new DateTime('2026-01-01 00:00:00');
```

## 🐛 Solución de Problemas

### Error de conexión a la base de datos
- Verifica que MySQL esté ejecutándose
- Confirma que las credenciales en `bbdd/server.php` sean correctas
- Asegúrate de que la base de datos `reyes_magos` exista

### Las imágenes no se cargan
- Verifica que las rutas en el código apunten correctamente a la carpeta `assets/`
- Asegúrate de que el servidor web tenga permisos de lectura en la carpeta `assets/`

### El CSS no se aplica
- Verifica que la ruta en `index.php` y `contador.php` sea correcta (`/css/style.css`)
- Si usas el servidor PHP integrado, asegúrate de estar en el directorio raíz del proyecto

## 📄 Licencia

Este proyecto es parte de una práctica académica.

## 👤 Autor

Lucas Ruiz González

## 🎅 Notas

- La aplicación utiliza `htmlspecialchars()` para prevenir ataques XSS
- Las consultas SQL utilizan prepared statements para prevenir inyección SQL
- El contador se actualiza mediante meta refresh (1 segundo) para simular tiempo real

---

¡Feliz Navidad! 🎄✨

