<?php
declare(strict_types=1);

/**
 
server.php
Conexión PDO a MySQL (cambia credenciales)*/

$host = '127.0.0.1';
$port = '3306';
$db   = 'reyes_magos';
$user = 'root';
$pass = ''; // cámbialo en tu entorno

$dsn = "mysql:host={$host};port={$port};dbname={$db};charset=utf8mb4";

try {
  $pdo = new PDO($dsn, $user, $pass, [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
  ]);
} catch (PDOException $e) {
  http_response_code(500);
  exit('No se pudo conectar con la base de datos.');
}
