<?php
declare(strict_types=1);
date_default_timezone_set('Europe/Madrid');

require_once __DIR__ . '/bbdd/server.php';

$sent = (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST');

$nombre    = $sent ? trim((string)($_POST['nombre'] ?? '')) : '';
$edad      = $sent ? (int)($_POST['edad'] ?? 0) : 0;
$direccion = $sent ? trim((string)($_POST['direccion'] ?? '')) : '';
$carta     = $sent ? trim((string)($_POST['carta'] ?? '')) : '';
$buen      = $sent ? (isset($_POST['buen_comportamiento']) ? 1 : 0) : 0;

$errors = [];
$ok = false;

if ($sent) {
  if ($nombre === '' || strlen($nombre) > 100)       { $errors[] = 'Nombre inválido.'; }
  if ($edad < 0 || $edad > 120)                         { $errors[] = 'Edad inválida.'; }
  if ($direccion === '' || strlen($direccion) > 255) { $errors[] = 'Dirección inválida.'; }
  if ($carta === '' || strlen($carta) > 5000)        { $errors[] = 'Carta inválida.'; }

  if (!$errors) {
    try {
      $stmt = $pdo->prepare(
        "INSERT INTO cartas_reyes (nombre, edad, direccion, carta, buen_comportamiento)
         VALUES (:nombre, :edad, :direccion, :carta, :buen)"
      );

      $stmt->execute([
        ':nombre'    => $nombre,
        ':edad'      => $edad,
        ':direccion' => $direccion,
        ':carta'     => $carta, // mantiene saltos de línea en DB
        ':buen'      => $buen,
      ]);

      $ok = true;

      // opcional: limpiar campos tras éxito
      $nombre = $direccion = $carta = '';
      $edad = 0;
      $buen = 0;

    } catch (Throwable $e) {
      $errors[] = 'No se pudo guardar la carta. Inténtalo más tarde.';
    }
  }
}

function e(string $s): string {
  return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Carta a los Reyes Magos</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link
        href="https://fonts.googleapis.com/css2?family=Mountains+of+Christmas:wght@400;700&family=Great+Vibes&family=Nunito:wght@300;400;600;800&display=swap"
        rel="stylesheet"
    >
    <link rel="stylesheet" href="/css/style.css">
</head>

<body class="page-index">

<div class="snow-layer snow-back"></div>
<div class="snow-layer snow-middle"></div>
<div class="snow-layer snow-front"></div>

<div class="page-wrapper">

    <header class="main-header">
        <h1 class="titulo-principal">Carta a los Reyes Magos</h1>
        <p class="subtitulo">Escribe tus deseos y mándalos directo a Oriente</p>

        <?php if ($ok): ?>
          <p class="subtitulo"><?php echo e('¡Tu carta ha llegado a Oriente!'); ?></p>
        <?php elseif ($sent && $errors): ?>
          <p class="subtitulo"><?php echo e($errors[0]); ?></p>
        <?php endif; ?>
    </header>

    <main class="main-content">
        <section class="scroll-container">

            <img class="reyes-background"
                src="/assets/reyes_magos.png"
                alt="Reyes Magos"
            >
            <div class="reyes-scroll">
                <div class="scroll-inner">
                    <h2 class="scroll-title">Queridos Reyes Magos...</h2>

                    <form action="" method="post" class="letter-form">
                        <div class="form-group">
                            <label for="nombre">Nombre completo</label>
                            <input type="text" id="nombre" name="nombre" required value="<?php echo e($nombre); ?>">
                        </div>

                        <div class="form-group">
                            <label for="edad">Edad</label>
                            <input
                                type="number"
                                id="edad"
                                name="edad"
                                min="0"
                                max="120"
                                required
                                value="<?php echo e((string)$edad); ?>"
                            >
                        </div>

                        <div class="form-group">
                            <label for="direccion">Dirección completa</label>
                            <input
                                type="text"
                                id="direccion"
                                name="direccion"
                                placeholder="Calle, ciudad, código postal"
                                required
                                value="<?php echo e($direccion); ?>"
                            >
                        </div>

                        <div class="form-group">
                            <label for="carta">Carta / deseos</label>
                            <textarea
                                id="carta"
                                name="carta"
                                rows="6"
                                placeholder="Queridos Reyes Magos..."
                                required
                            ><?php echo e($carta); ?></textarea>
                        </div>

                        <div class="form-group form-check">
                            <label class="checkbox-label">
                                <input
                                    type="checkbox"
                                    name="buen_comportamiento"
                                    value="1"
                                    <?php echo $buen ? 'checked' : ''; ?>
                                >
                                <span class="custom-checkbox"></span>
                                Me he portado bien este año
                            </label>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn btn-wax-seal">
                                <span class="btn-text">Enviar carta a Oriente</span>
                                <span class="seal">✶</span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="gift-link-wrapper">
                <a href="/contador.php">
                    <div class="uvas">
                        <div class="uva u1"></div>
                        <div class="uva u2"></div>
                        <div class="uva u3"></div>
                        <div class="uva u4"></div>
                        <div class="uva u5"></div>
                        <div class="uva u6"></div>
                        <div class="uva u7"></div>
                        <div class="hoja"></div>
                    </div>
                </a>
            </div>
            <span class="gift-text">¡Dale a las uvas para ver el contador!</span>
            <span class="gift-subtext">¡Ya queda menos!</span>
        </section>
    </main>

    <footer class="main-footer">
        <p>¡Feliz Navidad!</p>
    </footer>
</div>
</body>
</html>
